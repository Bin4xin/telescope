#!/bin/bash
Green_font_prefix="\033[32m" && Red_font_prefix="\033[31m" &&  Font_color_suffix="\033[0m"
DIR_PATH=$(dirname $(realpath "$0"))

PATH=${PATH}:${DIR_PATH}/bin:.
export LD_LIBRARY_PATH=${DIR_PATH}/lib:${LD_LIBRARY_PATH}

if [ "$#" -eq 0 ]; then
	echo -e "\n${Red_font_prefix}Please carry the command parameters to execute!${Font_color_suffix}\nFor example: $0 nmap -V\n"
else
	$SHELL -c "$*"
fi

